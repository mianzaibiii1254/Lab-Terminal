import React from 'react'
import Button from 'react-bootstrap/Button';

import { useState, useEffect } from 'react';

function Posts() {
    const [posts, setPosts] = useState([]);
    const [total, setTotal] = useState(0);
    const [skip, setSkip] = useState(0);
    const [limit] = useState(10);

    useEffect(() => {
        async function fetchData() {
            const response = await fetch(`https://dummyjson.com/posts?skip=${skip}&limit=${limit}` );
            const data = await response.json();

            setPosts(data.posts);
            setTotal(data.total);
        }
        fetchData();
    }, [skip, limit]);
    
    return ( 
        <div>
            <h1>API FETCH POST Request</h1>
            <h4>"Post"</h4>
            {posts.map((post) => (
                <div key={post.id}>
                    <p>"Post id": {post.id}</p>
                    <h3>Title: "{post.title}"</h3>
                    <ul className='React-user'>
                        <li>"Reactions": {post.reactions}</li>
                        <li className='user-id'>User ID: {post.userId}</li>
                    </ul>
                </div>
            ))}
            <div>
                <p>TOTAL: {total}</p>
                <p>Skip: {skip}</p>
                <p>Limit: {limit}</p>
                <Button  onClick={() => setSkip(skip - limit)} disabled={skip === 0}>
                    Previous
                </Button>
                <Button onClick={() => setSkip(skip + limit)} disabled={skip + limit >= total}>
                    Next
                </Button>
                <span>
                    Page {skip / limit + 1} of {Math.ceil(total / limit)}
                </span>
            </div>
        </div>
     );
}

export default Posts;